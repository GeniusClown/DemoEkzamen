﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace _205ig_crud.page
{
    /// <summary>
    /// Логика взаимодействия для EditWorkers.xaml
    /// </summary>
    public partial class EditWorkers : Page
    {
        public OpenFileDialog ofd = new OpenFileDialog();
        private string newsourthpath = string.Empty;
        string path = "";
        private bool flag = false;
        public EditWorkers(models.Workers selectedWorker)
        {
            InitializeComponent();
            if (selectedWorker != null) currentworker = selectedWorker;
            DataContext = currentworker;
        }

        private models.Workers currentworker = new models.Workers();
        DateTime datetoday = DateTime.Now;
        DateTime timenow = DateTime.Now;

        private void Save(object sender, RoutedEventArgs e)
        {
            currentworker.data = datetoday;
            currentworker.time = datetoday.TimeOfDay;

            StringBuilder errors = new StringBuilder();
            if (string.IsNullOrWhiteSpace(currentworker.fio))
                errors.AppendLine("Укажите ФИО сотрудника");
            if (string.IsNullOrWhiteSpace(currentworker.login))
                errors.AppendLine("Укажите Логин сотрудника");
            if (string.IsNullOrWhiteSpace(currentworker.password))
                errors.AppendLine("Укажите Пароль сотрудника");
            if (currentworker.password.Length < 5)
            {
                errors.AppendLine("Пароль должен быть больше 5 символов");
            }
            if (errors.Length > 0)
            {
                MessageBox.Show(errors.ToString(), "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            else
            {
                if (currentworker.id == 0)
                    models.CRUD_205igEntities3.GetContext().Workers.Add(currentworker);
                try
                {
                    models.CRUD_205igEntities3.GetContext().SaveChanges();
                    MessageBox.Show("all good");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("not good");
                }
            }
        }



        private void Choose_image(object sender, RoutedEventArgs e)
        {
            string Source = Environment.CurrentDirectory;
            if (ofd.ShowDialog() == true)
            {
                flag = true;
                string sourthpath = ofd.SafeFileName;
                newsourthpath = Source.Replace("/bin/Debug", "/img/") + sourthpath;
                PreviewImage.Source = new BitmapImage(new Uri(ofd.FileName));
                path = ofd.FileName;
                currentworker.photo = $"/img/{ofd.SafeFileName}";
            }
        }
    }
}
