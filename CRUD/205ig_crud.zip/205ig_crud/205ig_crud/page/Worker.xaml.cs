﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace _205ig_crud.page
{
    /// <summary>
    /// Логика взаимодействия для Page1.xaml
    /// </summary>
    public partial class Worker : Page
    {
        public Worker()
        {
            InitializeComponent();
            DGWorkers.ItemsSource = models.CRUD_205igEntities3.GetContext().Workers.ToList(); 
        }

        private void Edit(object sender, RoutedEventArgs e)
        {
            classes.manager.MainFrame.Navigate(new page.EditWorkers((sender as Button).DataContext as models.Workers));
        }

        private void add(object sender, RoutedEventArgs e)
        {
            classes.manager.MainFrame.Navigate(new page.EditWorkers(null));
        }

        private void delete(object sender, RoutedEventArgs e)
        {
            var WorkerForRemoving = DGWorkers.SelectedItems.Cast<models.Workers>().ToList();
            if (MessageBox.Show($"Вы точно хотите удалить {WorkerForRemoving.Count}?", "Предупреждение", MessageBoxButton.YesNo, MessageBoxImage.Warning) == MessageBoxResult.Yes)
            try
            {
                models.CRUD_205igEntities3.GetContext().Workers.RemoveRange(WorkerForRemoving);
                models.CRUD_205igEntities3.GetContext().SaveChanges();
                MessageBox.Show("deleted");
            }
            catch (Exception ex)
            {
                MessageBox.Show("not deleted");
            }
        }

        private void QR(object sender, RoutedEventArgs e)
        {
            classes.manager.MainFrame.Navigate(new QRKOD());
        }
    }
}
